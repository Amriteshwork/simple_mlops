Create env

```bash
conda create wineq python -y
```
Install the req
```bash
pip install -r requirements.txt
```

```bash
git init
```

```bash
dvc init
```

```bash
dvc add data_given/winequality.csv
```

```bash
git add .
```


```bash
git commit -m "first commit"
```